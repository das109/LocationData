install.packages('devtools')
install_github('dkahle/ggmap', ref='tidyup')
install.packages('tidyverse')
install.packages('rvest')
install.packages('httr')
install.packages('jsonlite')


library('devtools')
library('ggmap')
library('tidyverse')
library('rvest')
library('jsonlite')
library('httr')

usethis::edit_r_environ()
googlekey <- Sys.getenv("GOOGLE_API_KEY")
register_google(key = googlekey)

mykey = 'ajXXfNZ2YR%2Byc2ich7AAmOfayw36bUsnvzVNU0QZTF%2Bjx7fhl%2F0kvgcM9QSqkuefnk8LhkJcwmlbIYLh788%2BqQ%3D%3D'
url <-"http://apis.data.go.kr/B551182/hospInfoService/getHospBasisList?"


res <- GET(url = url, query = list(sidoCd = '110000', zipCd = '2010', servicekey = mykey %>% I()))
res %>% content(as = 'text', encoding = "UTF-8") %>% fromJSON() -> json

df1 <- json$response$body$items$item

res <- GET(url = url, query = list(sidoCd = '110000', zipCd = '2030', servicekey = mykey %>% I()))
res %>% content(as = 'text', encoding = "UTF-8") %>% fromJSON() -> json2

df2 <- json2$response$body$items$item

df <- rbind(df1, df2)

addr_v = c()

for (tmp in df['addr']) {addr_v <- tmp}


gc <- geocode(enc2utf8(addr_v))


df$위도 <- NA
df$경도 <- NA

for (i in 1:nrow(x=df)) {
  df$위도[i] <-gc$lat[i]
  df$경도[i] <-gc$lon[i]
}


center <- c(lon = median(x=df$경도), lat= median(x=df$위도))

qmap(location = c(lon=center[1], lat=center[2]),
     zoom = 11,
     maptype = 'hybrid',
     source = 'google') + geom_point(data = df, mapping= aes (x=경도, y= 위도, color = sgguCdNm),
                                     shape = 19,
                                     size = 5) + theme(legend.position = 'None')
write.csv(df, file="서울병원.xlsx")
